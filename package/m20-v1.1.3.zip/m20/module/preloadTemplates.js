export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "systems/m20/templates"
    ];
    return loadTemplates(templatePaths);
};
